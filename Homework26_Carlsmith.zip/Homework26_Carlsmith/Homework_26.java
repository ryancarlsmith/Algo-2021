/*
Ryan Carlsmith
Homework 26
4/14/22
 */

import java.util.Scanner;

public class Homework_26 {
    public static void main (String[] args) {
        Scanner s = new Scanner(System.in);
        SymbolGraph g = SymbolGraph.readEdgeList(s);
        g.DFSRunner();

    }
}
