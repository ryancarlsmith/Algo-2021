/*
Ryan Carlsmith
Homework 25
4/9/22
 */


public class GraphProperties {

    private boolean[] visited;
    private int[] distance;
    FixedSizeQueue<SymbolGraph.Vertex> queue;
    private SymbolGraph graph;
    private int eccentricity = 0;

    public GraphProperties(SymbolGraph graph) {
        visited = new boolean[graph.vertices()];
        distance = new int[graph.vertices()];
        queue = new FixedSizeQueue<SymbolGraph.Vertex>(graph.vertices());
        for (int i =0; i < visited.length; i++){
            visited[i] = false;
        }
        this.graph = graph;
        BFSRunner(graph);
    }

    public void BFS(SymbolGraph graph, SymbolGraph.Vertex start) {
        visited = new boolean[graph.vertices()];
        distance = new int[graph.vertices()];
        distance[start.index()] = 0;
        visited[start.index()] = true;
        queue.enqueue(start);
        SymbolGraph.Vertex vertex = start;
        visited[start.index()] = true;
        while (!queue.isEmpty()) {
            vertex = queue.dequeue(); //select next node to visit

            for (SymbolGraph.Vertex v : vertex.neighbors()) {
                if (visited[v.index()] == false) { //add if its not visited
                    visited[v.index()] = true;
                    queue.enqueue(v);
                    distance[v.index()] = distance[vertex.index()]+1;

                    if (distance[v.index()] > start.eccentricity()) {
                        start.setEccentricity(distance[v.index()]);
                    }
                }
            }
        }
    }
    public void BFSRunner(SymbolGraph graph){
        for (int i = 0; i < graph.vertices(); i++) {
            SymbolGraph.Vertex v = graph.get(i);
            BFS(graph, v); // will set the eccentricity for all vertex
        }

    }


    public int eccentricity(SymbolGraph.Vertex vertex) { // the longest shortest path
        return this.eccentricity;
    }

    public int diameter() { // max of eccentricity
        int diameter = 0;
        for (int i = 0; i < graph.vertices(); i++) {
            SymbolGraph.Vertex v = graph.get(i);
            if (v.eccentricity() > diameter) {
                diameter = v.eccentricity();
            }
        }
        return diameter;
    }

    public int radius() { // min of eccentricity
        int radius = Integer.MAX_VALUE;
        for (int i = 0; i < graph.vertices(); i++) {
            SymbolGraph.Vertex v = graph.get(i);
            if (v.eccentricity() < radius) {
                radius = v.eccentricity();
            }
        }
        return radius;
    }

    public SymbolGraph.Vertex center() {  // vertex whose eccentricity = radius
        SymbolGraph.Vertex result = null;
        for (int i = 0; i < graph.vertices(); i++) {
            SymbolGraph.Vertex v = graph.get(i);
            if (v.eccentricity() == radius()) {
                result = v;
                System.out.println(v.name() + " is a center");
            }
        }
        return result;
    }
}
