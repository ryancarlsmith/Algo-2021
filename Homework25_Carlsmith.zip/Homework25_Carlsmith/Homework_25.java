/*
Ryan Carlsmith
Homework 25
4/9/22
 */

public class Homework_25 {
    public static void main(String[] args) {
        SymbolGraph graph = new SymbolGraph();
        for (State s : States.continentalStates) {
            graph.addVertex(s.name());
        }
        // add all the edges
        for (State s : States.continentalStates) {
            for (State n : s.neighbors()) {
                graph.addEdge(s.name(), n.name());
            }
        }

        GraphProperties gp = new GraphProperties(graph);
        System.out.println("Radius: " + gp.radius());
        System.out.println("Diameter: " + gp.diameter());
        gp.center(); //prints all centers in the method bc there are multiple


    }


}
