//Ryan Carlsmith
//HW 16
//Algorithms
//1/22/21

public class CountingSort {

    public static interface Numbering<T> {

        // Assigns integer values to objects of type T.  CountingSort
        // will sort items in the order specified by this numbering
        // of the objects of type T.  Note this numbering need not be
        // unique (two different objects may have the same number -
        // and they will be considered "equal" in the sorting order.

        //write so number is the number of char in the generic

        public int ordinal(T item);
        }



    public static<T> void sort(T[] a, Numbering<T> numbering, int min, int max) {

        for (int i = 0; i < a.length; i++) {
            numbering.ordinal(a[i]);
        }

        int arrLength = a.length;
        if (arrLength == 0)
            return;
        int range = max - min + 1;

        int[] count = new int[range];
        T[] temp = (T[]) new Object[arrLength];
        // initialize the occurrence of each element in the count array

        for (int i = 0; i < arrLength; i++) {

            int j = numbering.ordinal(a[i]);
            count[j - min]++;
        }
        // calculate sum of indexes
        for (int i = 1; i < range; i++)
            count[i] += count[i - 1];
        // modify original array according to the sum count

        for (int i = arrLength - 1; i >= 0; i--) {
            int num = numbering.ordinal(a[i]);
            count[num - min]--;
            temp[count[num - min]] = a[i];
        }
        for (int i = 0; i < arrLength; i++) {
            a[i] = temp[i];

        }
    }


    public static<T> void sort(T[] a, Numbering<T> numbering) {
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (T item : a) {
            int ord = numbering.ordinal(item);
            if (ord < min) min = ord;
            if (ord > max) max = ord;
        }

        sort(a, numbering, min, max);
    }


    public static void sort(int a[], int min, int max) {
        // TODO (but not required)
    }

    public static void sort(int a[]) {
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (int item : a) {
            if (item < min) min = item;
            if (item > max) max = item;
        }
        sort(a, min, max);
    }
}
