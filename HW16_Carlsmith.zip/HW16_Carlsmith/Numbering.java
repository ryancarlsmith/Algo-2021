//Ryan Carlsmith
//HW 16
//Algorithms
//1/22/21

public class Numbering <T> implements CountingSort.Numbering {


    @Override
    public int ordinal(Object item) {
        if(item instanceof String){
            return ((String) item).length();
        }
        return 0;
    }


}
