//Ryan Carlsmith
//HW 16
//Algorithms
//1/22/21

import java.util.ArrayList;
import java.util.Scanner;

public class Homework_16 {

    public static void sortStringsByLength(String[] args) {

        CountingSort.sort(args, new Numbering<String>());
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            ArrayList<String> list = new ArrayList<>();
            Scanner scanner = new Scanner(System.in);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                list.add(line);
            }
            args = list.toArray(args);
        }
        sortStringsByLength(args);
        for (String arg : args) {
            System.out.println(arg);
        }
    }
}
