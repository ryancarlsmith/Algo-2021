// Ryan Carlsmith
// Algorithms
// Homework #18

import java.util.Random;

public class BinarySearchTree<Key extends Comparable<Key>, Value> {

    private class Node {

        public Key   key;
        public Value value;
        public Node  left;
        public Node  right;

        public Node(Key key, Value value) {
            this.key = key;
            this.value = value;
            this.left = left;
            this.right = right;
        }
    }

    private Node root;


    public BinarySearchTree() {
        this.root = null;
    }

    private int size(Node node) {
        if (node != null) {
            return size(node.left) + size(node.right) + 1;
        } else {
            return 0;
        }
    }

    public int size() {
        return size(this.root);
    }

    private int height(Node node) {
        if (node != null) {
            return 1 + Math.max(height(node.left), height(node.right));
        } else {
            return 0;
        }
    }

    public int height() {
        return height(this.root);
    }

    public Value find(Key key) {
        // Return the value associated with the specified key
        // Return null if the key is not found in the BST
        Node rover = this.root;
        while (rover != null) {
            int compare = key.compareTo(rover.key);
            if (compare < 0) {
                rover = rover.left;
            } else if (compare > 0) {
                rover = rover.right;
            } else {
                return rover.value;
            }
        }
        return null;
    }

    public boolean contains(Key key) {
        return find(key) != null;
    }

    public Key min() {
        // Return the key of the least key found in
        // the BST and null if the tree is empty
        if (isEmpty()){
            return null;
        }
        Node rover = this.root;
        while (rover.left != null){
            rover = rover.left;
        }
        return rover.key;
    }

    public Node min(Node start) {
        // Return the key of the least key found in
        // the BST and null if the tree is empty
        if (start == null){
            return null;
        }
        Node rover = start;
        while (rover.left != null){
            rover = rover.left;
        }
        return rover;
    }

    private boolean isEmpty() {
        return size() == 0;
    }

    public Key max() {
        // Return the key of the greatest key found in
        // the BST and null if the tree is empty
        if (isEmpty()){
            return null;
        }
        Node rover = this.root;
        while (rover.right != null){
            rover = rover.right;
        }
        return rover.key;
    }
    public Node max(Node start) { //might use
        // Return the key of the greatest key found in
        // the BST and null if the tree is empty
        if (start == null){
            return null;
        }
        Node rover = start.left;
        Node parent = start;
        while (rover.right != null){
            parent = rover;
            rover = rover.right;
        }
        parent.right = null; //deletes the max leaf that got moved in remove method
        return rover;
    }


    public Key floor(Key key) {
        // Return the key of the greatest item in the BST
        // that is less than or equal to the specified key
        if (isEmpty()){
            return null;
        }
        Node rover = this.root;
        Key floor = null;
        while (rover != null){
            if (rover.key == key){
                return rover.key;
            }
            if (rover.key.compareTo(key) < 0){
                floor = rover.key;
                rover = rover.right;
            }
            else {
                rover = rover.left;
            }
        }
        return floor;
    }

    public Key ceiling(Key key) {
        // Return the key of the smallest item in the BST
        // that is greater than or equal to the specified key
        if (isEmpty()){
            return null;
        }
        Node rover = this.root;
        Key ceil = null;
        while (rover != null){
            if (rover.key == key){
                return rover.key;
            }
            if (rover.key.compareTo(key) > 0){
                ceil = rover.key;
                rover = rover.left;
            }
            else {
                rover = rover.right;
            }
        }
        return ceil;
    }

    private static enum Direction { NIL, LEFT, RIGHT }

    public void add(Key key, Value value) {
        // Add a new key/value pair to the tree if it is not
        // already in the BST (update the key/value pair
        // in the BST if it is already containted in the BST
        Node parent = null;
        Node rover = this.root;
        Direction direction = Direction.NIL;
        while (rover != null) {
            int compare = key.compareTo(rover.key);
            if (compare < 0) {
                parent = rover;
                rover = rover.left;
                direction = Direction.LEFT;
            } else if (compare > 0) {
                parent = rover;
                rover = rover.right;
                direction = Direction.RIGHT;
            } else { // found (update key/value)
                rover.key = key;
                rover.value = value;
                return;
            }
        }

        // Create a new node and update the
        // proper link in the parent node

        Node node = new Node(key, value);
        switch (direction) {
            case NIL:
                this.root = node;
                break;

            case LEFT:
                parent.left = node;
                break;

            case RIGHT:
                parent.right = node;
                break;
        }
    }

    public Value remove(Key key) {

        // Remove a node with a specified key from the BST
        // Returns the value of the removed key if it is
        // found in the BST and returns null if it is not
        //randomize the direction
        if (isEmpty()){
            return null;
        }
        if (size() == 1){
            this.root = null;
        }
        Node rover = this.root;
        Node parent = null;
        Value result = null;
        while (rover != null) {
            int compare = key.compareTo(rover.key);
            if (compare < 0) {
                parent = rover;
                rover = rover.left;
            } else if (compare > 0) {
                parent = rover;
                rover = rover.right;
            } else {
                result = rover.value;
                //case 1: leaf node
                if (rover.left == null && rover.right == null) {
                    if (rover != root)
                    {
                        if (parent.left == rover) {
                            parent.left = null;
                        }
                        else {
                            parent.right = null;
                        }
                    }
                    // if the tree has only a root node, set it to null
                    else {
                        root = null;
                    }
                }
                //Case 2: 2 children
                else if (rover.left != null && rover.right != null){
                    // find its inorder successor node
                    Node successor = min(rover.right);

                    // store successor value
                    Key val = successor.key;

                    // recursively delete the successor. Note that the successor
                    // will have atamost one child (right child)
                    remove(successor.key);

                    // copy value of the successor to the current node
                    rover.key = val;
                }
                //Case 3: 1 child
                else{
                    Node child = (rover.left != null)? rover.left: rover.right;

                    // if the node to be deleted is not a root node, set its parent
                    // to its child
                    if (rover != root)
                    {
                        if (rover == parent.left) {
                            parent.left = child;
                        }
                        else {
                            parent.right = child;
                        }
                    }

                    // if the node to be deleted is a root node, then set the root to the child
                    else {
                        root = child;
                    }
                }
                return root.value;
            }
        }
        return result;
    }

    public static interface Visit<Key, Value> {
        public void visit(Key key, Value value, int level);
    }

    private void preOrderTraversal(Node node, Visit<Key, Value> visit, int level) {
        if (node != null) {
            visit.visit(node.key, node.value, level);
            preOrderTraversal(node.left, visit, level+1);
            preOrderTraversal(node.right, visit, level+1);
        }
    }

    private void inOrderTraversal(Node node, Visit<Key, Value> visit, int level) {
        if (node != null) {
            inOrderTraversal(node.left, visit, level+1);
            visit.visit(node.key, node.value, level);
            inOrderTraversal(node.right, visit, level+1);
        }
    }

    private void postOrderTraversal(Node node, Visit<Key, Value> visit, int level) {
        if (node != null) {
            postOrderTraversal(node.left, visit, level+1);
            postOrderTraversal(node.right, visit, level+1);
            visit.visit(node.key, node.value, level);
        }
    }

    public void traversePreOrder(Visit<Key, Value> visit) {
        preOrderTraversal(this.root, visit, 0);
    }

    public void traverseInOrder(Visit<Key, Value> visit) {
        inOrderTraversal(this.root, visit, 0);
    }

    public void traversePostOrder(Visit<Key, Value> visit) {
        postOrderTraversal(this.root, visit, 0);
    }
}
