/*
Ryan Carlsmith
Homework 28
5/7/22
 */

public class Homework_28 {
    public static void main(String[] args) {
        States.initialize();
        SymbolGraph graph = new SymbolGraph();
        for (State s : States.states) {
            graph.addVertex(s.name());
        }
        for (State s : States.states) {
            for (State n : s.neighbors()) {
                graph.addEdge(s.name(), n.name());
            }
        }
        graph.fwRunner();
    }
}
