public interface Queue<T> {

    public static class OverflowException extends RuntimeException {
        public OverflowException() {
            super();
        }
    }

    public static class UnderflowException extends RuntimeException {
        public UnderflowException() {
            super();
        }
    }

    public boolean isEmpty();
    public void enqueue(T item);
    public T dequeue();
    public T head();

}
