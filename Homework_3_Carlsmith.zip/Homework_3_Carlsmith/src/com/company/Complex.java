//Ryan Carlsmith
//Algorithims
//Homework #3
//9/10/21
package com.company;

public class Complex implements Comparable<Complex> {
// instance

    private final double a; //format a + bi
    private final double b;
//constants

    public static final Complex ONE = new Complex(1, 0);
    public static final Complex ZERO = new Complex(0, 0);
    public static final Complex I = new Complex(0, 1);

    public Complex(double real, double imaginary) {
        this.a = real;
        this.b = imaginary;

    }

    public String toString() {
        if (b == 0) {
            return a + "";
        } else if (a == 0) {
            return b + "i";
        }
        if (b >= 0) {
            return a + " + " + b + 'i';
        } else {
            return a + " - " + -b + 'i';
        }
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Complex && this.equals((Complex) other);
    }

    @Override
    public int compareTo(Complex other) {
        if (this.Modulus() > other.Modulus() || (this.Modulus() == other.Modulus() && this.arg() < other.arg())) {
            return 1;
        } else if (this.Modulus() > other.Modulus() || (this.Modulus() == other.Modulus() && this.arg() > other.arg())) {
            return 0;
        } else {
            return 0;
        }
    }

    public double re() {
        return a;
    }

    public double im() {
        return b;
    }

    public boolean equals(Complex other) {
        return other != null
                && this.a == other.a
                && this.b == other.b;
    }

    public Complex Negation() { //works
        return new Complex(-this.a, -this.b);
    }

    public Complex Conjugate() {
        return new Complex(this.a, -this.b);
    }

    public Complex Expo(int n) {
        Complex ex = Complex.ZERO;

        if (n == 0) {
            return Complex.ONE;
        } else if (n > 0) {
            for (int i = 0; i < n; i++) {
                ex = ex.Multiplication(this);
            }
        } else if (n < 0) {
            return Complex.ONE.Division(ex);
        }
        return ex;
    }

    public Complex Addition(Complex other) {
        double real = this.a + other.a;
        double im = this.b + other.b;
        return new Complex(real, im);
    }

    public Complex Subtraction(Complex other) {
        double real = this.a - other.a;
        double im = this.b - other.b;
        return new Complex(real, im);
    }

    public Complex Multiplication(Complex other) {
        double real = (this.a * other.a) - (this.b * other.b);
        double im = (this.b * other.a) + (this.a * other.b);
        return new Complex(real, im);
    }

    public Complex Squaring() {

        return this.Multiplication(this);
    }

    public Complex Division(Complex other) {
        double nR = (this.a * other.a + this.b * other.b);
        double dR = Math.pow(other.a, 2) + Math.pow(other.b, 2);
        double nIM = (this.b * other.a - this.a * other.b);
        double dIM = Math.pow(other.a, 2) + Math.pow(other.b, 2);

        return new Complex(nR / dR, nIM / dIM);
    }

    public double Modulus() {

        return Math.sqrt(Math.pow(this.a, 2) + Math.pow(this.b, 2));
    }

    public double Identity() {

        return Math.pow(this.Modulus(), 2);
    }

    public double arg() {
        if (this.a == 0) {
            return -1;
        }
        return Math.atan2(this.b, this.a);
    }
}
