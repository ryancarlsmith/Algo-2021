
//Ryan Carlsmith
//Algorithims
//Homework #3
//9/10/21
package com.company;

import java.lang.Math;
import static java.lang.Math.sqrt;

public class Homework_3 {

    public static void main(String[] args) {
        Mandelbrot mandelbrot = new Mandelbrot();
        String expecting = "real";
        double re = 0.0;
        double im = 0.0;

        for (String arg : args) {
            switch (arg) {
                case "-limit":
                    expecting = "limit";
                    continue;
            }

            switch (expecting) {
                case "limit":
                    expecting = "real";
                    try {
                        int limit = Integer.parseInt(arg);
                        mandelbrot = new Mandelbrot(limit);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid value for limit: " + arg);
                        continue;
                    }
                    continue;

                case "real":
                    expecting = "immaginary";
                    try {
                        re = Double.parseDouble(arg);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid value for real part: " + arg);
                        continue;
                    }
                    continue;

                case "immaginary":
                    expecting = "real";
                    try {
                        im = Double.parseDouble(arg);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid value for immaginary part: " + arg);
                        continue;
                    }
            }

            // Construct the complex number and test it for membership
            // in the Mandelbrotset.  Print the result of the test.
            Complex z = new Complex(re, im);
            if (mandelbrot.isInMandelbrotSet(z)) {
                System.out.println(z + " is in the Mandelbrot set");
            } else {
                int escape = mandelbrot.escapeTime(z);
                System.out.println(z + " is not in the Mandelbrot set (" + escape + ")");
            }
        }
    }
}
