//Ryan Carlsmith
//Algorithims
//Homework #3
//9/10/21
package com.company;

public class Mandelbrot {

    private int iterations;

    public Mandelbrot(int inter) {
        this.iterations = inter;
    }

    public Mandelbrot() {
        this.iterations = 1000;
    }

    public boolean isInMandelbrotSet(Complex c) {
        Complex z = Complex.ZERO;
        for (int i = 0; i < this.iterations; i++) {
            z = z.Squaring();
            z = z.Addition(c);
            if (z.Modulus() > 2) {
                return false;
            }
        }
        return true;

    }

    public int escapeTime(Complex c) {
        Complex z = Complex.ZERO;
        for (int i = 0; i < this.iterations; i++) {
            z = z.Squaring();
            z = z.Addition(c);
            if (z.Modulus() > 2) {
                return i;
            }
        }
        return this.iterations;
    }
}
