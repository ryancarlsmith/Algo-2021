/*
Ryan Carlsmith
Algo
Homework 22
3/12/22
 */

import java.util.Iterator;

public class SeparateChainingHashMap<Key, Value> implements Map<Key, Value> {

    public class Pair {

        private final Key key;
        private final Value value;

        public Pair(Key key, Value value) {
            this.key = key;
            this.value = value;
        }

        public Key key() {
            return this.key;
        }

        public Value value() {
            return this.value;
        }
    }


    private class List implements Iterable<Pair> {

        private class Node {

            private final Key key;
            private Value value;
            private Node next;

            public Node(Key key, Value value) {
                this.key = key;
                this.value = value;
                this.next = null;
            }
        }


        private Node head;

        public List() {
            this.head = null;
        }

        public boolean contains(Key key) {
            Node rover = this.head;
            while (rover != null) {
                if (rover.key.equals(key)) return true;
                rover = rover.next;
            }
            return false;
        }

        public Value find(Key key) {
            Node rover = this.head;
            while (rover != null) {
                if (rover.key.equals(key)) return rover.value;
                rover = rover.next;
            }
            return null;
        }

        public boolean add(Key key, Value value) {
            Node rover = this.head;
            while (rover != null) {
                if (rover.key.equals(key)) {
                    rover.value = value;
                    return false;
                }
                rover = rover.next;
            }

            Node node = new Node(key, value);
            node.next = this.head;
            this.head = node;
            return true;
        }

        public boolean remove(Key key) {
            Node current = this.head;
            Node previous = null;
            while (current != null) {
                if (current.key.equals(key)) {
                    if (previous != null) {
                        previous.next = current.next;
                    } else {
                        this.head = current.next;
                    }
                    return true;
                }
                previous = current;
                current = current.next;
            }
            return false;
        }


        public Iterator<Pair> iterator() {
            return new ListIterator();
        }


        private class ListIterator implements Iterator<Pair> {

            private List.Node current = List.this.head;

            @Override
            public boolean hasNext() {
                return current != null;
            }

            @Override
            public Pair next() {
                Pair result = new Pair(current.key, current.value);
                current = current.next;
                return result;
            }
        }
    }


    private static class Array<T> implements Iterable<T> {

        private final T[] array;

        public Array(int size) {
            this.array = (T[]) new Object[size];
        }

        public int size() {
            return this.array.length;
        }

        public T get(int index) {
            return this.array[index];
        }

        public void set(int index, T value) {
            this.array[index] = value;
        }

        @Override
        public Iterator<T> iterator() {
            return new ArrayIterator();
        }

        public class ArrayIterator implements Iterator<T> {

            private int current = 0;

            @Override
            public boolean hasNext() {
                return this.current < Array.this.array.length;
            }

            @Override
            public T next() {
                return Array.this.array[this.current++];
            }
        }
    }


    private final Array<List> map;
    private final int capacity;
    private int size;

    private int hash(Key key) {
        return (key.hashCode() & 0x7FFFFFFF) % this.capacity;
    }

    public SeparateChainingHashMap(int capacity) {
        this.map = new Array<>(capacity);
        this.capacity = capacity;
        this.size = 0;

        for (int i = 0; i < capacity; i++) {
            this.map.set(i, new List());
        }
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public int capacity() {
        return this.capacity;
    }

    @Override
    public boolean contains(Key key) {
        return this.map.get(hash(key)).contains(key);
    }

    @Override
    public Value find(Key key) {
        return this.map.get(hash(key)).find(key);
    }

    @Override
    public void add(Key key, Value value) {
        boolean added = this.map.get(hash(key)).add(key, value);
        if (added) this.size++;
    }

    @Override
    public void remove(Key key) {
        boolean removed = this.map.get(hash(key)).remove(key);
        if (removed) this.size--;
    }

    public void traverse(Map.Visit visit) { // the passive iterator
        map.forEach(e -> e.forEach(f -> visit.visit(f.key, f.value.toString()))); //e goes through hashtable, f goes through each list
    }

    public Iterator<Key> iterator() { //the active iterator
        return new HashIterator();
    }

    public class HashIterator<Key> implements Iterator<Key> {
        private Iterator currentTable;
        private final Iterator listIterator = map.iterator();
        private int remaining = size;

        public HashIterator() {
            currentTable = ((List) listIterator.next()).iterator();
        }

        @Override
        public boolean hasNext() {
            return listIterator.hasNext() && remaining > 0;
        }

        @Override
        public Key next() {
            if (currentTable.hasNext()) {
                remaining--;
                return (Key) ((Pair) currentTable.next()).key();
            } else if (!currentTable.hasNext() && listIterator.hasNext()) {
                currentTable = ((List) listIterator.next()).iterator();
                return next();
            }
            return null;
        }
    }
}

