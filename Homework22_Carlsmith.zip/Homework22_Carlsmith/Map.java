/*
Ryan Carlsmith
Algo
Homework 22
3/12/22
 */

public interface Map<Key, Value> extends Iterable<Key> {

    // Size.
    //
    //   The size method returns the number of keys in the map.
    //   the capacity method returns the size of the table.

    int size();
    int capacity();

    default double loadFactor() {
        return ((double) size()) / ((double) capacity());
    }


    // Lookup.
    //
    //   Value returns the value associated with a specified key
    //   and returns null if the key is not found in the map.

    boolean contains(Key key);
    Value find(Key key);


    // Add and remove keys from the map.
    //
    //   Add will update the value if the key is found in the map.
    //   Remove is a no-op if the key is not in the map.

    void add(Key key, Value value);
    void remove(Key key);


    // Iteration.
    //
    //   The traverse method is a passive iterator for the map.

    void traverse(Visit visit);

    interface Visit<Key, Value> {
        void visit(Key key, Value value);
    }

}
