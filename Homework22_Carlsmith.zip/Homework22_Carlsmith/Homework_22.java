/*
Ryan Carlsmith
Algo
Homework 22
3/12/22
 */

public class Homework_22 {

    static Map<String, Counter> table;

    public static void main(String[] args) {
        table = new SeparateChainingHashMap<>(args.length);
        for (String s : args){
            Homework_22.add(s, new Counter());
        }

        table.traverse(new Map.Visit<String, String>() {
            @Override
            public void visit(String key, String value) {
                System.out.println(key + ": " + value);
            }
        });

        System.out.println();
        for (String s : table){
            System.out.println(s);
        }
    }

    public static void add(String key, Counter value){
        if (table.contains(key)){
            table.find(key).increment();
        }
        else{
            table.add(key, value);
        }
    }
}

