/*
Rehan Parwani
Algorithms H
10/20/2021
Homework 7
*/
import java.util.Iterator;
import java.util.List;

public class Array<T>{

    public static class EmptyArrayException extends RuntimeException {
        public EmptyArrayException() {
            super();
        }
    }

    private static final int MINIMUM_CAPACITY = 4;
    private static final int DEFAULT_CAPACITY = 8;

    private T[] items;
    private int size;

    public Array() {
        this(4);
    }

    public Array(int capacity) {
        if (capacity < 0) {
            throw new IllegalArgumentException("Capacity: " + capacity);
        }
        capacity = Math.max(capacity, MINIMUM_CAPACITY);
        this.items = (T[]) new Object[capacity];
        this.size = 0;
    }

    public Array(T item) {
        this();
        this.append(item);
    }

    public Array(T[] items) {
        this(items.length);
        for (T item : items) {
            this.append(item);
        }
    }

    public Array(List<T> items) {
        this(items.size());
        for (T item : items) {
            this.append(item);
        }
    }

    private void resizeIfNecessary() {
        if (this.size >= this.items.length) {
            T[] old = this.items;
            this.items = (T[]) new Object[2*this.items.length];
            for (int i = 0; i < this.size; i++) {
                this.items[i] = old[i];
            }
        }
    }

    public int size() {
        return this.size;
    }

    public int capacity() {
        return this.items.length;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }
    
    public boolean contains(T item) {
        for (int i = 0; i < this.size; i++) {
            if (equal(this.items[i], item)) return true;
        }
        return false;
    }
    

    public int occurrences(T item) {
        int count = 0;
        for (int i = 0; i < this.size; i++) {
            if (equal(this.items[i], item)) count++;
        }
        return count;
    }

    public int locate(T item) {
        for (int i = 0; i < this.size; i++) {
            if (equal(this.items[i], item)) return i;
        }
        return -1;
    }

    private void checkIndexBounds(int index) {
        if (index < 0 || index >= this.size) {
            throw new ArrayIndexOutOfBoundsException("Index: " + index);
        }
    }

    public T get(int index) {
        checkIndexBounds(index);
        return this.items[index];
    }

    public void set(int index, T value) {
        checkIndexBounds(index);
        this.items[index] = value;
    }

    public void prepend(T item) {
        resizeIfNecessary();
        for (int i = this.size-1; i >= 0; i--) {
            this.items[i+1] = this.items[i];
        }
        this.items[0] = item;
        this.size++;
    }

    public void append(T item) {
        resizeIfNecessary();
        this.items[this.size++] = item;
    }

    public void insertAfter(int position, T item) {
        checkIndexBounds(position);
        resizeIfNecessary();
    
        for (int i = this.size-1; i > position; i--) {
            this.items[i+1] = this.items[i];
        }
        this.items[position+1] = item;
        this.size++;
    }

    public void insertBefore(int position, T item) {
        checkIndexBounds(position);
        resizeIfNecessary();

        for(int i = this.size-1; i >= position; i--) {
            this.items[i+1] = this.items[i];
        }

        this.items[position] = item;
        this.size++;
    }

    public T remove(int index) {
        checkIndexBounds(index);
        T result = this.items[index];

        for (int i = index; i < this.size-1; i++) {
            this.items[i] = this.items[i+1];
        }

        this.size--;
        return result;
    }

    public void removeAll(T item) {
        int n = this.size;
        int j = 0;
        for (int i = 0; i < n; i++) {
            if (equal(this.items[i], item)) {
                this.items[j++] = this.items[i];
                this.size--;
            }
        }
    }

    public T head() {
        if (this.size == 0) {
            throw new EmptyArrayException();
        } else {
            return this.items[0];
        }
    }

    public T tail() {
        if (this.size == 0) {
            throw new EmptyArrayException();
        } else {
            return this.items[size-1];
        }
    }

    public T removeHead() {
        if (this.size == 0) {
            throw new EmptyArrayException();
        } else {
            return remove(0);
        }
    }

    public T removeTail() {
        if (this.size == 0) {
            throw new EmptyArrayException();
        } else {
            return remove(this.size-1);
        }
    }

    private boolean equal(T x, Object y) {
        if (x == null) {
            return y == null;
        } else {
            return x.equals(y);
        }
    }

    public boolean equals(Array other) {
        if (other == null) return false;
        if (this.size != other.size) return false;

        for (int i = 0; i < this.size; i++) {
            T thisItem = this.items[i];
            Object otherItem = other.get(i);
            if ( ! equal(thisItem, otherItem)) return false;
        }
        return true;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Array && this.equals((Array) other);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        for (int i = 0; i < this.size; i++) {
            hash = 751 * hash + this.items[i].hashCode();
        }
        return hash;
    }

    @Override
    public String toString() {
        String separator = "";
        String result = "[";
        for (int i = 0; i < this.size; i++) {
            result += separator;
            result += this.items[i].toString();
            separator = ",";
        }
        result += "]";
        return result;
    }

    public Iterator<T> iterator() {
        return this.new ArrayIterator();
    }

    private class ArrayIterator implements Iterator<T> {

        private int index;

        public ArrayIterator() {
            this.index = 0;
        }

        @Override
        public boolean hasNext() {
            return this.index < Array.this.size;
        }

        @Override
        public T next() {
            return Array.this.items[this.index++];
        }
    }
}

