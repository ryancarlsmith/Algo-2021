/*
Rehan Parwani
Algorithms H
10/20/2021
Homework 7
*/
public class ArrayStack<T> implements Stack<T>{
    public static class OverflowException extends RuntimeException {
        public OverflowException() {
            super();
        }
    }

    public static class UnderflowException extends RuntimeException {
        public UnderflowException() {
            super();
        }
    }
    
    private Array<T> items;
    private int sp;
    
    public ArrayStack(){
        this.items = new Array<T>();
        this.sp = 0;
    }
    
    public ArrayStack(int capacity){
        this.items = new Array<T>(capacity);
        this.sp = 0;
    }
    
    public boolean isEmpty(){
        return this.items.size() == 0;
    }
    
    public void push(T item){
        if (this.sp == this.items.size()){
            this.items.append(item);
            this.sp++;
        }else{
            this.items.set(this.sp++, item);
        }
    }
    
    public T pop() throws UnderflowException{
        if (this.sp == 0){
            throw new UnderflowException();
        }
        T item = this.items.remove(--this.sp);
        return item;
    }
    
    public T top(){
        if (this.sp == 0){
            return null;
        }
        return this.items.get(this.sp - 1);
    }
    
    public int size(){
        return this.items.size();
    }
}
