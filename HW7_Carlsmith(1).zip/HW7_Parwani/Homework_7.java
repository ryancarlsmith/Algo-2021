/*
Rehan Parwani
Algorithms H
10/20/2021
Homework 7
*/
public class Homework_7 {
    public static void main(String[] args) {
        ArrayStack<Integer> operands = new ArrayStack<>();
        input: for (String arg : args){
            switch (arg){
                case "x":
                    try{
                        int value2 = operands.pop();
                        int value1 = operands.pop();
                        operands.push(value1 * value2);
                    }catch (ArrayStack.UnderflowException e){
                        System.out.println("Stack Underflow: Too many Operators entered");
                    }
                    break;
                case "/":
                    try{
                        int value2 = operands.pop();
                        int value1 = operands.pop();
                        operands.push(value1 / value2);
                    }catch (ArrayStack.UnderflowException e){
                        System.out.println("Stack Underflow: Too many Operators entered");
                    }
                    break;
                case "+":
                    try{
                        int value2 = operands.pop();
                        int value1 = operands.pop();
                        operands.push(value1 + value2);
                    }catch (ArrayStack.UnderflowException e){
                        System.out.println("Stack Underflow: Too many Operators entered");
                    }
                    break;
                case "-":
                    try{
                        int value2 = operands.pop();
                        int value1 = operands.pop();
                        operands.push(value1 - value2);
                    }catch (ArrayStack.UnderflowException e){
                        System.out.println("Stack Underflow: Too many Operators entered");
                    }
                    break;
                default:
                    try{
                       int value = Integer.parseInt(arg);
                       operands.push(value);
                    }catch(NumberFormatException e){
                        System.out.println("Invalid Character(s) Entered");
                        break input;
                    }
                    break;
            }
        }
        if (operands.size() > 1){
            System.out.println("Stack Overflow: Too many operands (numbers) entered");
        }else{
            try{
                System.out.println(operands.pop());
            }catch(ArrayStack.UnderflowException e){
                System.out.println("Too many operators entered");
            }
            
        }
    }
}
