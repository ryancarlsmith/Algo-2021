/*
Rehan Parwani
Algorithms H
10/20/2021
Homework 7
*/
public interface Stack<T> {

    public boolean isEmpty();
    public void push(T item);
    public T pop();
    public T top();
}
