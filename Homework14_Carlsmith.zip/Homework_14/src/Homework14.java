//Ryan Carlsmith
//Algorithms H
//Homework 14
//12/13/21

import java.util.Arrays;

public class Homework14 {

    private static boolean isLess(Comparable a, Comparable b) {
        return Statistics.isLess(a, b);
    }

    private static void merge(Comparable[] from, Comparable[] into, int lo, int mid, int hi) {
        int i = lo;
        int j = mid+1;
        int k = lo;
        while (i <= mid && j <= hi) {
            if(isLess(from[i], from[j])) {
                into[k++] = from[i++];
            } else {
                into[k++] = from[j++];
            }

        }
        while (i <= mid) {
            into[k++] = from[i++];

        }
        while (j <= hi) {
            into[k++] = from[j++];

        }
    }

    public static void sort(Comparable[] a) {
        int n = a.length;
        Comparable[] a2 = Arrays.copyOf(a, n);
        boolean temp = true;
        for (int size = 1; size < n; size += size) {
            for (int lo = 0; lo < n - size; lo += 2 * size) {
                int hi = Math.min(lo + 2 * size - 1, n - 1);
                int mid = lo + size - 1;
                if (temp) {
                    merge(a, a2, lo, mid, hi);
                } else {
                    merge(a2, a, lo, mid, hi);
                }
            }
            temp = !temp;
        }
    }
            public static void main (String[]args){
                sort(args);
                for (String arg : args) {
                    System.out.println(arg);
                }
            }
    }

