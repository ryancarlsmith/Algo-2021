//Ryan Carlsmith
//Algorithms H
//Homework 14
//12/13/21

public class Statistics {

    public static int compares = 0;
    public static int moves = 0;
    public static int swaps = 0;
    public static int calls = 0;
    public static int depth = 0;
    public static int maxDepth = 0;

    public static void enter() {
        Statistics.calls++;
        Statistics.depth++;
        Statistics.maxDepth = Math.max(Statistics.maxDepth, Statistics.depth);
    }

    public static void exit() {
        depth--;
    }

    public static void swap(Object[] a, int i, int j) {
        if (i != j) {
            Statistics.moves += 2;
            Statistics.swaps++;
            Object temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
    }

    public static boolean isLess(Comparable a, Comparable b) {
        Statistics.compares++;

        Comparable temp1 = a;
        Comparable temp2 = b;
        if (a instanceof String){
            temp1 = ((String) ((String) a).toLowerCase());
        }
        if (b instanceof String){
            temp2 = ((String) ((String) b).toLowerCase());
        }

        return temp1.compareTo(temp2) < 0;
    }

}
