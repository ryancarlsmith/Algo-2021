import java.util.Scanner;

public class DoublyLinkedListTest {

    public static void main(String[] args) {
        DoublyLinkedList<String> list = new DoublyLinkedList<>(args);
        Scanner scanner = new Scanner(System.in);

        boolean done = false;
        do {
            System.out.print("Command: ");
            String line = scanner.nextLine();
            if (line == null) break;

            String command = "";
            String value1 = "";
            String value2 = "";

            String[] fields = line.split(" ");
            if (fields.length > 0) command = fields[0];
            if (fields.length > 1) value1 = fields[1];
            if (fields.length > 2) value2 = fields[2];

            try {
                switch (command.toLowerCase()) {
                    case "size":
                        System.out.println(list.size());
                        break;

                    case "empty":
                        System.out.println(list.isEmpty());
                        break;

                    case "contains":
                        System.out.println(list.contains(value1));
                        break;

                    case "occurs":
                    case "occurrences":
                        System.out.println(list.occurrences(value1));
                        break;

                    case "prepend":
                        list.prepend(value1);
                        break;

                    case "append":
                        list.append(value1);
                        break;

                    case "after":
                    case "insertafter":
                        list.insertAfter(list.find(value1), value2);
                        break;

                    case "before":
                    case "insertbefore":
                        list.insertBefore(list.find(value1), value2);
                        break;

                    case "remove":
                        list.remove(list.find(value1));
                        break;

                    case "removeall":
                        list.removeAll(value1);
                        break;

                    case "head":
                        System.out.println(list.head());
                        break;

                    case "tail":;
                        System.out.println(list.tail());
                        break;

                    case "removehead":
                        System.out.println(list.removeHead());
                        break;

                    case "removetail":
                        System.out.println(list.removeTail());
                        break;

                    case "tostring":
                        System.out.println(list.toString());
                        break;

                    case "print":
                        for (String s : list) {
                            System.out.println(s);
                        }
                        break;

                    case "rprint":
                        list.reverse();
                        for (String s : list) {
                            System.out.println(s);
                        }
                        break;

                    case "clear":
                        list = new DoublyLinkedList<String>();
                        break;

                    case "new":
                        String[] values = new String[fields.length-1];
                        for (int i = 1; i < fields.length; i++) {
                            values[i-1] = fields[i];
                        }
                        list = new DoublyLinkedList<String>(values);
                        break;

                    case "exit":
                    case "quit":
                        done = true;
                        break;

                    case "help":
                        System.out.println("size              Print size()");
                        System.out.println("empty             Print isEmpty");
                        System.out.println("contains x        Print constains(x)");
                        System.out.println("occurrences x     Print occurrences(x)");
                        System.out.println("append x          Invoke append(x)");
                        System.out.println("prepend x         Invoke prepend(x)");
                        System.out.println("insertAfter x y   Invoke insertAfter(locate(x), y)");
                        System.out.println("insertBefore x y  Invoke insertBefore(locate(x), y)");
                        System.out.println("remove x          Invoke remove(locate(x))");
                        System.out.println("removeAll x       Invoke removeAll(x)");
                        System.out.println("removeHead        Print removeHead())");
                        System.out.println("removeTail        Print removeHead()");
                        System.out.println("head              Print head()");
                        System.out.println("tail              Print tail()");
                        System.out.println("toString          Print toString()");
                        System.out.println("print             Print list using the iterator");
                        System.out.println("rprint            Print list using the reverse iterator");
                        System.out.println("clear             new SinglyLinekdList()");
                        System.out.println("new a b ... z     new SinglyLinkedList(new T() {a, b, ..., z}");
                        System.out.println("quit              exits progam");
                        System.out.println("exit              exits progam");
                        break;

                    default:
                        System.out.println("Invalid command: " + command);
                        break;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } while (!done);
    }
}