/*
Rehan Parwani
Algorithms H
Mr. Paige
Homework 6
September 21, 2021
*/
public class Homework_6 {
    public static void main(String[] args) {
        States.initialize();
        Tour newTour = new Tour();
        newTour.append(States.continentalStates[0].capital());
        for (int i = 1; i < States.continentalStates.length; i++){
            try{
                City closestCity = newTour.closestCity(States.continentalStates[i].capital());
                newTour.insertBefore(closestCity, States.continentalStates[i].capital());
            }catch(NullPointerException e){
                System.err.println(e.getMessage());
            }
        }
        System.out.println(newTour);
        System.out.println("Tour Length: " + String.format("%.1f", newTour.length()));
    }
}
