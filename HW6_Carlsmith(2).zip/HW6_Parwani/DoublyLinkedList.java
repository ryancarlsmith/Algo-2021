/*
Rehan Parwani
Algorithms H
Mr. Paige
Homework 6
September 21, 2021
*/
import java.util.Iterator;
import java.lang.Iterable;

public class DoublyLinkedList<T> implements Iterable<T> {

    // This class implements a doubly linked list of items of class T.
    // Each node in the list has pointer to both the next item and the
    // previous item in the list.  This should allow for fast insertion
    // and removal of elements when a position (Node) within the list
    // is known.  It should also permit iteration of the list in the
    // reverse order.
    private Node head;
    private Node tail;
    private int size;

    private class Node {

        // Make sure that clients cannot create or modify nodes.
        // They can pass a Node to methods in this class or they
        // can get the value field out of a node ... nothing else.
        public T data;
        public Node next;
        public Node previous;

        private Node(T data) {
            this.data = data;
        }

        public T get() {
            return data;
        }
        
        @Override
        public String toString(){
            return this.data.toString();
        }
    }

    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    public DoublyLinkedList(T item) {
        // Create a list containing just this one item.
        this.append(item);
    }

    public DoublyLinkedList(T[] items) {
        // Create a list containing these items (same order).
        for (T item : items) {
            this.append(item);
        }
    }

    public T head() {
        return this.head.get();
    }

    public T tail() {
        return this.tail.get();
    }

    public int size() {
        // Returns the number of items currently in this list.
        return this.size;
    }

    public boolean isEmpty() {
        return this.size() == 0;
    }

    public boolean contains(T item) {
        // Check to see if a given item is in a list.
        return this.occurrences(item) > 0;
    }

    public int occurrences(T item) {
        // Return the number of times that the specified item
        // occurs in this linked list.
        int count = 0;
        for (T val : this) {
            if (item.equals(val)) {
                count++;
            }
        }
        return count;
    }

    public Node find(T item) {
        // Locate the node for the specified item in the list.
        // If it does not occur in the list then return null.
        // If it occurs more than once, return the first occurrence.
        Node current = this.head;
        while (current != null) {
            if (current.data.equals(item)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    public T get(int index) throws IndexOutOfBoundsException {
        // Get the value of the ith element in this list.
        // Throw an IndexOutOfBoundsException if necessary.
        int count = 0;
        for (T item : this) {
            if (count == index) {
                return item;
            }
            count++;
        }
        throw new IndexOutOfBoundsException("Invalid Index: " + index);
    }

    public void set(int index, T value) throws IndexOutOfBoundsException {
        // Set the value of the ith element in this list.
        // Throw an IndexOutOfBoundsException if necessary.
        Node current = this.head;
        int indice = 0;
        while (current != null) {
            if (index == indice) {
                current.data = value;
                return;
            }
        }
        throw new IndexOutOfBoundsException("Invalid Index: " + index);
    }
    
    public void reverse(){
        Node current = this.head;
        Node previous = null;
        while (current != null){
            current.previous = current.next;
            current.next = previous;
            previous = current;
            current = current.previous;
        }
        Node t = this.tail;
        this.tail = this.head;
        this.head = t;
    }

    public void append(T item) {
        // Append an item to the end of this list.
        Node newNode = new Node(item);
        if (this.size() == 0) {
            this.head = newNode;
        } else {
            newNode.previous = this.tail;
            this.tail.next = newNode;
        }
        this.tail = newNode;
        this.size++;
    }

    public void prepend(T item) {
        // Prepend an item to the beginning of this list.
        Node newNode = new Node(item);
        if (this.size() == 0) {
            this.head = newNode;
        } else {
            this.head.previous = newNode;
            newNode.next = this.head;
        }
        this.head = newNode;
        this.size++;
    }
    

    public void remove(T item){
        // Remove all occurrences of this item from the list.
        Node previous = null;
        Node current = this.head;

        while (current != null) {
            if (current.data.equals(item)) {
                if (previous != null) {
                    previous.next = current.next;
                } else {
                    this.head = current.next;
                }
                if (current.next == null){
                    current.next.previous = previous;
                }
                this.size--;
            }
            previous = current;
            current = current.next;
        }
    }
    
    public void insertBefore(Node node, T value) throws NullPointerException {
        // Insert a new item before a specified node in the list.
        if (node == null) {
            throw new NullPointerException("Invalid Node Passed (Insert Before)");
        }
        if (node.previous == null){
            this.prepend(value);
        }else{
            this.insertAfter(node.previous, value);
        }
    }

    public void insertAfter(Node node, T value) throws NullPointerException {
        // Insert a new item after a specified node in the list.
        if (node == null) {
            throw new NullPointerException("Invalid Node Passed (Insert After)");
        }
        Node newNode = new Node(value);
        newNode.next = node.next;
        newNode.previous = node;
        if (node.next != null){
            node.next.previous = newNode;
        }
        node.next = newNode;
        if (node == this.tail){
            this.tail = newNode;
        }
        this.size++;
    }

    public void remove(Node node) throws NullPointerException {
        // Remove a specified node from the list.
        if (node == null) {
            throw new NullPointerException("Node not found. Node data: " + node.data);
        }
        if (node == this.tail){
            this.tail = node.previous;
            if (this.tail != null){
                this.tail.next = null;
            }
        }
        
        if (node == this.head){
            this.head = node.next;
            if (this.head != null){
                this.head.previous = null;
            }
        }else{
            node.next.previous = node.previous;
            node.previous.next = node.next;
        }
        
        
        if (this.tail == null){
            this.head = null;
        }
        if (this.head == null){
            this.tail = null;
        }
        this.size--;
    }

    public void removeAll(T item) {
        Node current = this.head;

        while (current != null) {
            if (current.get().equals(item)) {
                this.remove(current);
            }
            current = current.next;
        }
    }

    public T removeHead() {
        T data = null;
        if (this.head != null) {
            data = this.head.get();
            this.head = this.head.next;
            this.head.previous = null;
        }
        return data;
    }

    public T removeTail() {
        T data = null;
        if (this.tail != null) {
            data = this.tail.get();
            this.tail = this.tail.previous;
            this.tail.next = null;
        }
        return data;
    }

    // Of course we always need equality predicates.
    public boolean equals(DoublyLinkedList other) {
        Iterator<T> iterator1 = other.iterator();
        for (T value : this) {
            if (iterator1.hasNext()) {
                if (!value.equals(iterator1.next())) {
                    return false;
                }
            } else {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean equals(Object other) {
        // Notice that we must use raw types here due to the problems with type erasure.
        return other instanceof DoublyLinkedList && this.equals((DoublyLinkedList) other);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        for (T item : this) {
            hash = 751 * hash + item.hashCode();
        }
        return hash;
    }

    @Override
    public String toString() {
        boolean first = true;
        String result = "[";
        for (T item : this) {
            if (!first) {
                result += ", ";
            }
            result += item;
            first = false;
        }
        result += "]";
        return result;
    }

    // Iterators for examining the elements in the linked list.
    @Override
    public Iterator<T> iterator() {
        // Returns the forward iterator
        return new ListIterator();
    }

    public static enum Direction {
        FORWARD, REVERSE
    }

    public Iterator<T> iterator(Direction direction) {
        return new ListIterator(direction);
    }

    private class ListIterator implements Iterator<T> {

        private Node current;
        private Direction direction;

        public ListIterator() {
            this.current = DoublyLinkedList.this.head;
            this.direction = Direction.FORWARD;
        }

        public ListIterator(Direction direction) {
            switch (direction) {
                case REVERSE:
                    this.current = DoublyLinkedList.this.tail;
                    break;
                default:
                    this.current = DoublyLinkedList.this.head;
                    break;
            }
            this.direction = direction;
        }

        public boolean hasNext() {
            return this.current != null;
        }

        public T next() {
            if (this.direction == Direction.FORWARD) {
                T data = this.current.get();
                this.current = current.next;
                return data;
            } else {
                T data = this.current.get();
                this.current = current.previous;
                return data;
            }
        }
    }

}
