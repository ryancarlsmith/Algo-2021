/*
Rehan Parwani
Algorithms H
Mr. Paige
Homework 6
September 21, 2021
*/
import java.util.Iterator;

public class Tour{
    
    DoublyLinkedList<City> tour;
    
    public Tour(){
        tour = new DoublyLinkedList<>();
    }
    
    public Tour(City c){
        tour = new DoublyLinkedList<>(c);
    }
    
    public Tour(City[] cities){
        tour = new DoublyLinkedList<>(cities);
    }
    
    public void append(City c){
        this.tour.append(c);
    }
    
    public void prepend(City c){
        this.tour.prepend(c);
    }
    
    public void insertBefore(City c, City newCity){
        this.tour.insertBefore(this.tour.find(c), newCity);
    }
    
    public void insertAfter(City c, City newCity){
        this.tour.insertAfter(this.tour.find(c), newCity);
    }
    
    public City closestCity(City city){
        double closestDistance = Double.MAX_VALUE;
        City closestCity = null;
        for (City c : this.tour){
            double distance = city.distance(c);
            if (distance < closestDistance){
                closestDistance = distance;
                closestCity = c;
            }
        }
        return closestCity;
    }
    
    public double length(){
        double distance = 0.0;
        Iterator<City> iterator = this.tour.iterator(DoublyLinkedList.Direction.REVERSE);
        City previous = null;
        for (City city : this.tour){
            if (previous == null){
                previous = city;
                continue;
            }
            distance += city.distance(previous);
            previous = city;
        }
        distance += this.tour.head().distance(this.tour.tail());
        return distance;
    }
    
    @Override
    public String toString(){
        String result = "";
        for (City c : this.tour){
            result += c + "\n";
        }
        return result;
    }
}
