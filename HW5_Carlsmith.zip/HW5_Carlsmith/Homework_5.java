//Ryan Carlsmith
//Mr. Paige
//Homework 5
//Algorithms H
//9/24/21

public class Homework_5 {

    public static void main(String[] args) throws DuplicateCityFound, StateNotValid {

        Tour t = new Tour();
        City c;
        boolean sign = true; //true is append, false is prepend
        for (String code : args) {
            if (code.equals("+")) {
                sign = true;

            } else if (code.equals("-")) {
                sign = false;

            } else if (code.charAt(0) == ('+')) {
                sign = true;
                String code1 = code.substring(1);

                try {
                    State currentState = States.find(code1);
                    c = currentState.capital();
                    t.append(c);

                } catch (StateNotValid e) {
                    System.out.println(e.getMessage() + code);
                }

            } else if (code.charAt(0) == ('-')) {
                sign = false;
                String code1 = code.substring(1);
                try {
                    State currentState = States.find(code1);
                    c = currentState.capital();

                    t.prepend(c);
                } catch (StateNotValid e) {
                    System.out.println(e.getMessage() + code);
                }
            } else {
                if (sign == true) {

                    try {
                        State currentState = States.find(code);
                        c = currentState.capital();
                        t.append(c);
                    } catch (StateNotValid e) {
                        System.out.println(e.getMessage() + code);
                    }
                } else {

                    try {
                        State currentState = States.find(code);
                        c = currentState.capital();
                        t.prepend(c);
                    } catch (StateNotValid e) {
                        System.out.println(e.getMessage() + code);
                    }
                }
            }

        }
        System.out.println(t);
    }
}
