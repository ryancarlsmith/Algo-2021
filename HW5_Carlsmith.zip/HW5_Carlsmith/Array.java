//Ryan Carlsmith
//Mr. Paige
//Homework 5
//Algorithms H
//9/24/21

public class Array<T> {

    public static final int DEFAULT_CAPACITY = 4;
    private int CAPACITY;
    private T[] arr;
    private int SIZE = 0;

    public Array() {
        this(DEFAULT_CAPACITY);
        CAPACITY = DEFAULT_CAPACITY;
    }

    public Array(int capacity) {
        this.arr = (T[]) new Object[capacity];
        CAPACITY = capacity;
    }

    public Array(T item) {
        // Creates an Array containing a single item
        this();
        this.append(item);

    }

    public Array(T[] items) {
        this.SIZE = items.length;
        arr = (T[]) new Object[items.length];
        for (int i = 0; i < arr.length; i++) { //or for each loop
            arr[i] = items[i];
        }
    }

    public int size() {

        return SIZE;

    }

    public int capacity() {

        return CAPACITY;
    }

    public boolean isEmpty() {
        return this.size() == 0;
    }

    public boolean contains(T item) {
        // Does this Array contain a specified item?
        for (int i = 0; i < this.size(); i++) {
            if (this.get(i).equals(item)) {
                return true;
            }
        }
        return false;
    }

    public int occurrences(T item) {
        // Returns the number of occurrences of the
        // specified item in this Array
        int count = 0;
        for (int i = 0; i < this.size(); i++) {
            if (this.get(i).equals(item)) {
                count++;
            }
        }
        return count;
    }

    public int locate(T item) {
        // Returns the position of the first occurrence
        // of the specified item in this Array
        for (int i = 0; i < this.size(); i++) {
            if (this.get(i).equals(item)) {
                return i;
            }
        }
        return -1;
    }

    public T get(int index) { //if(index < 0 || index <= size{ throw new indiex out of bounds
        // Returns the item at a specified position in the Array
        // Note: index must be in the range 0 .. size
        // TODO
        try {
            return arr[index];
        } catch (ArrayIndexOutOfBoundsException E) {
            System.err.println(E.getMessage() + index);
            return null;
        }
    }

    public void set(int index, T value) {
        if (arr[index] == null) {
            this.SIZE ++;
        }
        arr[index] = value;

    }

    public void append(T item) {
        // Appends an item to the end of the Array
        // The Array capacity is increased if there is insufficient
        // insufficient room for the new item
        // TODO
        T[] obj = (T[]) new Object[this.CAPACITY];

        if (this.get(this.capacity() - 1) != null) {
            obj = (T[]) new Object[this.arr.length * 2];
            this.CAPACITY *= 2;
            for (int i = 0; i < this.arr.length; i++) {
                obj[i] = this.get(i);

            }
            obj[this.arr.length] = item;
            this.SIZE ++;
            this.arr = obj;
        } else {
            this.arr[SIZE] = item;
            this.SIZE ++;

        }
    }

    public void prepend(T item) {
        // Prepends an item to be beginning of the Array
        // All items are shifted over one position to the right
        // to make room for the new item; the Array capacity is
        // increased if there is insufficient room for the new item
        // TODO
                T[] obj = (T[]) new Object[this.CAPACITY];

        if (this.get(this.capacity() - 1) != null) {
            obj = (T[]) new Object[this.arr.length * 2];
            this.CAPACITY *= 2;
            for (int i = 1; i < this.arr.length+1; i++) {
                obj[i] = this.get(i-1);

            }
            obj[0] = item;
            this.SIZE ++;
          
            this.arr = obj;
        } else {
            for (int i =this.SIZE-1; i>=0; i--){ 
                arr[i+1] = arr[i] ;
            }
            arr[0]=item;
            this.SIZE ++;
          
            

        }
    }

    public boolean equals(Array other) { //test
        if (other == null) {
            return false;
        }
        if (this.arr.length != other.size()) { //?
            return false;
        }
        for (int i = 0; i < this.arr.length; i++) {
            if (!this.arr[i].equals(other.get(i))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Array && this.equals((Array) other);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        for (int i = 0; i < this.size(); i++) {
            hash = 751 * hash + get(i).hashCode();
        }
        return hash;
    }

    @Override
    public String toString() {
        String toReturn = "[";
        for (T i : arr){
            toReturn += i + ", ";
        }
        toReturn += "]";
        return toReturn;
    }
}
