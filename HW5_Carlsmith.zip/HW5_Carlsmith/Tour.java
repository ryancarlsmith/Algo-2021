//Ryan Carlsmith
//Mr. Paige
//Homework 5
//Algorithms H
//9/24/21
public class Tour {

    // A class to represent a tour of a set of cities
    // Note: a tour includes returning to the start
    // You MUST use your Array class to implmement this class
    private Array<City> tour;

    public Tour() {
        this.tour = new Array(); 
    }

    public int size() {
        // The number of cities in this tour
        
        return tour.size();
    }

    public void append(City city) throws DuplicateCityFound{
        if (tour.contains(city)){
        throw new DuplicateCityFound("already touring city");
        }
        else{
        tour.append(city);
        }
    }

    public void prepend(City city) throws DuplicateCityFound{
        if (tour.contains(city)){
        throw new DuplicateCityFound("already touring city");
        }
        tour.prepend(city);
    }

    public City get(int index) {

        try {
            return tour.get(index);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getMessage() + ": " + index);
        }
        return tour.get(index);

    }

    public double length() {
        // Return the length of this tour in miles
        // This includes the distance to return to
        // the starting city
      
        double totalDistance = 0.0;
        for (int i = 0; i < tour.size()-1; i++) {
           totalDistance += tour.get(i).distance(tour.get(i+1));

        }
        totalDistance += tour.get(tour.size()-1).distance(tour.get(0));
        return totalDistance;
    }

    public boolean equals(Tour other) {
        if (other == null) {
            return false;
        }
        if (other.size() != this.size()) {
            return false;
        }
        for (int i = 0; i < this.size(); i++) {
            if (this.get(i).equals(other.get(i))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Tour && this.equals((Tour) other);
    }

    @Override
    public String toString() {
        String cities = "";
        for (int i=0; i<tour.size(); i++){
            if(tour.get(i) != null){
                cities += ((City) tour.get(i)).toString();
                cities += "\n";
            }
        }
        cities += String.format("%.1f", this.length());
        return cities;
    }
} 
