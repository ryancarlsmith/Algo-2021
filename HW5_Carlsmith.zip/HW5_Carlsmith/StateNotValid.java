//Ryan Carlsmith
//Mr. Paige
//Homework 5
//Algorithms H
//9/24/21

public class StateNotValid extends Exception {

    public StateNotValid(String errorMessage) {
        super(errorMessage);
    }

}
