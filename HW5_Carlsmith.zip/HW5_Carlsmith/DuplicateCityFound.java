//Ryan Carlsmith
//Mr. Paige
//Homework 5
//Algorithms H
//9/24/21
public class DuplicateCityFound extends Exception {

    public DuplicateCityFound(String errorMessage) {
        super(errorMessage);
        
    }
}
