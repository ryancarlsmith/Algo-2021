/*
Ryan Carlsmith
Homework 23
3/26/22
 */

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;

public class LinearProbingHashMap<Key, Value> implements Map<Key, Value> {

    private int size;
    private int capacity;
    private Array<Key> keys;
    private Array<Value> vals;

    private static class Array<T> implements Iterable<T> {

        private final T[] array;

        public Array(int size) {
            this.array = (T[]) new Object[size];
        }

        public int size() {
            return this.array.length;
        }

        public T get(int index) {
            return this.array[index];
        }

        public void set(int index, T value) {
            this.array[index] = value;
        }

        @Override
        public Iterator<T> iterator() {
            return new ArrayIterator();
        }

        public class ArrayIterator implements Iterator<T> {

            private int current = 0;

            @Override
            public boolean hasNext() {
                return this.current < Array.this.array.length;
            }

            @Override
            public T next() {
                return Array.this.array[this.current++];
            }
        }
    }

    public LinearProbingHashMap (int capacity){
        this.size = 0;
        this.capacity = capacity;
        keys = new Array<Key>(capacity);
        vals = new Array<Value>(capacity);
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public int capacity() {
        return this.capacity;
    }

    @Override
    public boolean contains(Key key) {
        return find(key) != null;
    }

    @Override
    public Value find(Key key) {
        int index = hash(key);
        while (keys.get(index) != null){
            if (keys.get(index).equals(key)){
                return vals.get(index);
            }
            index = index + 1 % this.capacity;
        }
        return null;
    }


    @Override
    public void add(Key key, Value value) {
        if (loadFactor() > 0.4){
            resize();
        }
        int index = hash(key);
        while (this.keys.get(index) != null){
            index = index + 1 % this.capacity;
        }
        this.keys.set(index, key);
        this.vals.set(index, value);
        this.size++;
    }

    private int hash(Key key) {
        return (key.hashCode() & 0x7FFFFFFF) % this.capacity;
    }

    private void resize(){
        int end = this.capacity;
        this.capacity = BigInteger.valueOf(this.capacity * 2).nextProbablePrime().intValue();
        Array<Key> tempKeys = this.keys;
        Array<Value> tempVals = this.vals;
        this.keys = new Array<>(this.capacity);
        this.vals = new Array<>(this.capacity);
        this.size = 0;
        for (int i =0; i < end; i++){
            if (tempKeys.get(i) != null){
               add(tempKeys.get(i), tempVals.get(i));
            }
        }
    }

    @Override
    public double loadFactor() {
        return ((double) size()) / ((double) capacity());
    }

    @Override
    public void remove(Key key) {
        if (!contains(key))
            return;

        int i = hash(key);
        while (!key.equals(keys.get(i))) {
            i = (i + 1) % this.capacity;
        }
        keys.set(i, null);
        vals.set(i, null);

        for (i = (i + 1) % this.capacity; keys.get(i) != null;
             i = (i + 1) % this.capacity) {
            Key tempK = keys.get(i);
            Value tempV = vals.get(i);
            keys.set(i, null);
            vals.set(i, null);
            this.size--;
            add(tempK, tempV);
        }
        this.size--;
    }

    @Override
    public void traverse(Visit visit) { //passive iterator
        keys.forEach(f -> {
            if(f!=null){
                visit.visit(f, find(f).toString());
            }
        });
    }

    @Override
    public Iterator<Key> iterator() { //active iterator
        return new HashIterator();
    }
    public class HashIterator<Key> implements Iterator<Key> {
        private int count = 0;
        private int rover = 0;

        @Override
        public boolean hasNext() {
            return count < LinearProbingHashMap.this.size;
        }

        @Override
        public Key next() {
            while (keys.get(rover) == null){
                rover++;
            }
            count++;
            return (Key) LinearProbingHashMap.this.keys.get(rover++);
        }
    }
}
