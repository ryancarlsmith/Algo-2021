/*
Ryan Carlsmith
Homework 23
3/26/22
 */

public class Counter{
    private int count;

    public Counter() {
        count = 1;
    }

    public void increment(){
        count++;
    }

    public int getCount(){
        return count;
    }

    @Override
    public String toString(){
        return "" + count;
    }
}