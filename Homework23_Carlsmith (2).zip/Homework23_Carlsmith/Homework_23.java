/*
Ryan Carlsmith
Homework 23
3/26/22
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Homework_23 {

    static Map<String, Counter> table;

    public static void main(String[] args) throws IOException{
        table = new LinearProbingHashMap<>(10);
        MaxPriorityQueue queue = new MaxPriorityQueue(20);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int i;
        while ((i= reader.read())!=-1) {
            Homework_23.add(reader.readLine(), new Counter());
        }


        table.traverse(new Map.Visit<String, String>() {
            @Override
            public void visit(String key, String value) {
               // System.out.println(key + ": " + value);
                queue.add(key);
            }
        });
        for (int j =0; j < 20; j++) {
            System.out.println(queue.removeMax().toString() + ": " + table.find(queue.removeMax().toString()));
        }

    }

    public static void add(String key, Counter value){
        if (table.contains(key)){
            table.find(key).increment();
        }
        else{
            table.add(key, value);
        }
    }
}

