/*
Ryan Carlsmith
Algorithms H
Homework 24
 */

import java.util.Scanner;

public class Homework_24 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SymbolGraph graph = new SymbolGraph();
        graph = SymbolGraph.readAdjacencyList(scanner);
        graph.DFSRunner();

    }
}
