//Ryan Carlsmith
//HW 17
//1/29/22

public class Homework_17 {
    public static void main(String[] args) {
        String[] data = Input.getStrings(args);
        radixSort.radixSort(data);

        for (String item : data) {
            System.out.println(item);
        }
        // Determine the number of unique strings in the array data
        int unique = 0;
        for (int i = 0; i < data.length - 1; i++) {
            if (!data[i].equals(data[i + 1])) {
                unique++;
            }
        }
        if (!data[data.length - 2].equals(data[data.length - 1])) {
            unique++;
        }
        System.out.println(unique);
    }
}