/*
Ryan Carlsmith
Homework 27
4/30/22
 */

public class Homework_27 {

    public static void main(String[] args) {
        States.initialize();
//        Canada.initialize();
        SymbolGraph graph = new SymbolGraph();

        for (State s : States.states) {
            graph.addVertex(s.name());

        }

        for (State s : States.states) {
            for (State n : s.neighbors()) {
                graph.addEdge(s.name(), n.name());
            }
        }

        /*
        for (State s : Canada.states) {
            graph.addVertex(s.name());

        }

        for (State s : Canada.states) {
            for (State n : s.neighbors()) {
                graph.addEdge(s.name(), n.name());
            }
        }
        */


        for (int i = 0; i < args.length; i++) {
            if (args[i].charAt(0) != '-') {
                graph.DijkstraRunnerAndPrint(args[i]);
            }
        }

    }
}
