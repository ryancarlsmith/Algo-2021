/*
Ryan Carlsmith
Homework 25
4/9/22
 */

public class FixedSizeQueue<T> implements Queue<T> {

    private T[] queue;
    private int head;
    private int tail;
    private int capacity;

    public FixedSizeQueue(int capacity) {
        this.queue = (T[]) new Object[capacity];
        this.capacity = capacity;
        this.head = 0;
        this.tail = 0;
    }

    public boolean isEmpty() {
        return this.head == this.tail;
    }

    public int size() {
        return this.tail - this.head;
    }

    public void enqueue(T item) {
        if (this.size() < this.capacity) {
            this.queue[this.tail++ % this.capacity] = item;
        } else {
            throw new Queue.OverflowException();
        }
    }

    public T dequeue() {
        if (this.size() > 0) {
            return this.queue[this.head++ % this.capacity];
        } else {
            throw new Queue.UnderflowException();
        }
    }

    public T head() {
        if (this.size() > 0) {
            return this.queue[this.head % this.capacity];
        } else {
            throw new Queue.UnderflowException();
        }
    }
}
