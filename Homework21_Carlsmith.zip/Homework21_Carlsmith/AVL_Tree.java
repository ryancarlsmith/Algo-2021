/*
Ryan Carlsmith
Algorithms H
Homework 21
 */

public class AVL_Tree<Key extends Comparable<Key>, Value> {

    private static enum Balance {

        LEFT,
        EVEN,
        RIGHT;

        public String toString() {
            switch(this) {
                case LEFT:  return "/";
                case EVEN:  return "-";
                case RIGHT: return "\\";
                default:    return "";
            }
        }
    }

    private class Node {

        Key     key;
        Value   value;
        Node    left;
        Node    right;
        Balance balance;

        public Node(Key key, Value value) {
            this.key     = key;
            this.value   = value;
            this.left    = null;
            this.right   = null;
            this.balance = Balance.EVEN;
        }
    }


    private Node root;

    public AVL_Tree() {
        this.root = null;
    }


    public boolean isEmpty() {
        return this.root == null;
    }


    private int size(Node node) {
        if (node != null) {
            return size(node.left) + size(node.right) + 1;
        } else {
            return 0;
        }
    }

    public int size() {
        return size(this.root);
    }


    private int height(Node node) {
        if (node != null) {
            return 1 + Math.max(height(node.left), height(node.right));
        } else {
            return 0;
        }
    }

    public int height() {
        return height(this.root);
    }


    public Key min() {
        Key result = null;
        Node rover = this.root;
        while (rover != null) {
            result = rover.key;
            rover = rover.left;
        }
        return result;
    }

    public Key max() {
        Key result = null;
        Node rover = this.root;
        while (rover != null) {
            result = rover.key;
            rover = rover.right;
        }
        return result;
    }


    public Key floor(Key key) {
        Key result = null;
        Node rover = this.root;
        while (rover != null) {
            int compare = key.compareTo(rover.key);
            if (compare < 0) {
                rover = rover.left;
            } else if (compare > 0) {
                result = rover.key;
                rover = rover.right;
            } else {
                return rover.key;
            }
        }
        return result;
    }


    public Key ceiling(Key key) {
        Key result = null;
        Node rover = this.root;
        while (rover != null) {
            int compare = key.compareTo(rover.key);
            if (compare < 0) {
                result = rover.key;
                rover = rover.left;
            } else if (compare > 0) {
                rover = rover.right;
            } else {
                return rover.key;
            }
        }
        return result;
    }


    public Value find(Key key) {
        Node rover = this.root;
        while (rover != null) {
            int compare = key.compareTo(rover.key);
            if (compare < 0) {
                rover = rover.left;
            } else if (compare > 0) {
                rover = rover.right;
            } else {
                return rover.value;
            }
        }
        return null;
    }


    public boolean contains(Key key) {
        Node rover = this.root;
        while (rover != null) {
            int compare = key.compareTo(rover.key);
            if (compare < 0) {
                rover = rover.left;
            } else if (compare > 0) {
                rover = rover.right;
            } else {
                return true;
            }
        }
        return false;
    }


    private class Result {

        boolean taller = false;
        Node    root   = null;

        public Result(Node node, boolean taller) {
            this.root = node;
            this.taller = taller;
        }
    }

    private Result taller(Node node) {
        return new Result(node, true);
    }

    private Result sameHeight(Node node) {
        return new Result(node, false);
    }

    private Result error() {
        assert false; // Enable assertions: java -ea AVL_Tree
        return new Result(null, false);
    }


    private Node rotateRight(Node node) {
        Node result = node.left;
        node.left = result.right;
        result.right = node;
        if (height(result.left) < height(result.right)){
            result.balance = Balance.RIGHT;
        }
        else if (height(result.left) > height(result.right)){
            result.balance = Balance.LEFT;
        }
        else{
            result.balance = Balance.EVEN;
        }
        if (height(result.left) < height(result.right)){
            node.balance = Balance.RIGHT;
        }
        else if (height(result.left) > height(result.right)){
            node.balance = Balance.LEFT;
        }
        else{
            node.balance = Balance.EVEN;
        }
        return result; // new root
    }

    private Node rotateLeft(Node node) {
        Node result = node.right;
        node.right = result.left;
        result.left = node;
        if (height(result.left) < height(result.right)){
            result.balance = Balance.RIGHT;
        }
        else if (height(result.left) > height(result.right)){
            result.balance = Balance.LEFT;
        }
        else{
            result.balance = Balance.EVEN;
        }
        if (height(result.left) < height(result.right)){
            node.balance = Balance.RIGHT;
        }
        else if (height(result.left) > height(result.right)){
            node.balance = Balance.LEFT;
        }
        else{
            node.balance = Balance.EVEN;
        }
        return result; // new root
    }

    private Node rotateLeftThenRight(Node node) {
        node.left = rotateLeft(node.left);
        node = rotateRight(node);
        return node; // new root
    }

    private Node rotateRightThenLeft(Node node) {
        node.right = rotateRight(node.right);
        node = rotateLeft(node);
        return node; // new root
    }


    private Result rebalanceLeftSubtree(Node node) {
        switch(node.balance) {
            case EVEN:
                node.balance = Balance.LEFT;
                return taller(node);

            case RIGHT:
                node.balance = Balance.EVEN;
                return sameHeight(node);

            case LEFT:
                Node left = node.left;
                switch (left.balance) {
                    case LEFT:
                        return sameHeight(rotateRight(node));

                    case RIGHT:
                        return sameHeight(rotateLeftThenRight(node));

                    case EVEN: // Can't happen
                        return error();
                }
        }
        return error(); // Can't get here
    }


    private Result rebalanceRightSubtree(Node node) {
        switch(node.balance) {
            case EVEN:
                node.balance = Balance.RIGHT;
                return taller(node);

            case RIGHT:
                Node right = node.right;
                switch (right.balance) {
                    case LEFT:
                        return sameHeight(rotateRightThenLeft(node));

                    case RIGHT:
                        return sameHeight(rotateLeft(node));

                    case EVEN: // Can't happen
                        return error();
                }
            case LEFT:
                node.balance = Balance.EVEN;
                return sameHeight(node);

        }
        return error(); // Can't get here
    }


    private Result add(Node node, Key key, Value value) {
        Result result;
        if (node == null) {

            // Create the new node and return it.  Note that the
            // newly created tree (height 1) is taller than the
            // empty tree (height zero).

            result = taller(new Node(key, value));

        } else {
            int compare = key.compareTo(node.key);
            if (compare < 0) {

                // The new node should be inserted into the left subtree.
                // If the left subtree got taller as a result of inserting
                // the new node, then it needs to be rebalaced.

                Result leftSubtree = add(node.left, key, value);
                node.left = leftSubtree.root;
                if (leftSubtree.taller) {
                    result = rebalanceLeftSubtree(node);
                } else {
                    result = sameHeight(node);
                }

            } else if (compare > 0) {

                // The new node should be inserted into the right subtree.
                // If the right subtree got taller as a result of inserting
                // the new node, then it needs to be rebalaced.

                Result rightSubtree = add(node.right, key, value);
                node.right = rightSubtree.root;
                if (rightSubtree.taller) {
                    result = rebalanceRightSubtree(node);
                } else {
                    result = sameHeight(node);
                }

            } else {

                // The key was already in the tree.  Just update the node's
                // key and value and we are done.  Note that the tree didn't
                // get any taller since no new node was added to the tree.

                node.key   = key;
                node.value = value;
                result =  sameHeight(node);
            }
        }

        return result;
    }


    public void add(Key key, Value value) {
        this.root = add(this.root, key, value).root;
    }


    // A method to check to see if a tree is height-balanced.
    // This is the interview question that we covered in class.

    private class BalancedAndHeight {

        boolean balanced;
        int     height;

        public BalancedAndHeight(boolean balanced, int height) {
            this.balanced = balanced;
            this.height = height;
        }
    }

    private BalancedAndHeight isBalanced(Node node) {
        if (node == null) {
            return new BalancedAndHeight(true, 0);
        } else {
            BalancedAndHeight left = isBalanced(node.left);
            BalancedAndHeight right = isBalanced(node.right);
            int height = 1 + Math.max(left.height, right.height);
            int difference = Math.abs (left.height - right.height);
            boolean balanced = left.balanced && right.balanced && difference < 2;
            return new BalancedAndHeight(balanced, height);
        }
    }

    public boolean isBalanced() {
        return isBalanced(root).balanced;
    }


    public static interface Visit<Key, Value> {
        public void visit(Key key, Value value, int level);

        void visit(String key, String value, int level);
    }

    private void traverse(Node node, Visit<Key, Value> visit, int level) {
        if (node != null) {
            traverse(node.left, visit, level+1);
            visit.visit(node.key, node.value, level);
            traverse(node.right, visit, level+1);
        }
    }

    public void traverse(Visit<Key, Value>  visit) {
        traverse(root, visit, 0);
    }
}
