//Ryan Carlsmith
//Mr. Paige
//Algorithms H
//1/15/22

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Homework_15 {

    public static void main(String[] args) throws FileNotFoundException {
        int i = 10;
        MaxQueue words = new MaxQueue();

        for (String x : args) {
            if (isNumeric(x) && i > 0) {
                i = Integer.parseInt(x);
            } else if (x.contains(".txt")) { //check for correct file
            }
        }

        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNextLine()) {
            words.enqueue(scanner.nextLine());
        }
        if (!words.isEmpty()) {
            if (i > words.size()){
                i = words.size();
            }
            for (int x = 0; x <= i - 1; x++) {
                System.out.println(words.dequeue());
            }
        }
    }

    public static boolean isNumeric(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }
}


