//Ryan Carlsmith
//Mr. Paige
//Algorithms H
//1/15/22

import java.util.ArrayList;
import java.util.Iterator;

public class MaxQueue implements PriorityQueue {
    private final ArrayList<String> Heap;
    private int size;


    public MaxQueue() {

        this.size = 0;
        Heap = new ArrayList<String>();
    }
        @Override
        public int size() {
            return this.size;
        }

    private int parent(int element) { return (element - 1) / 2; }

    private int leftChild(int element){
        return (element*2) + 1;
    }

    private int rightChild(int element){
        return (element * 2) + 2;
    }


    private void swap(int first, int second) {
        String temp = Heap.get(first);
        Heap.set(first, Heap.get(second));
        Heap.set(second, temp);
    }


        @Override
        public boolean isEmpty() {
            return this.size == 0;
        }


    private void sink(int i){
            int current = i;
            if (leftChild(i) <= size()
                    && Heap.get(leftChild(i)).length() > Heap.get(current).length()) {
                current = leftChild(i);
            }
            if (rightChild(i) <= size()
                    && Heap.get(rightChild(i)).length() > Heap.get(current).length()) {
                current = rightChild(i);
            }

            if (i != current) {
                swap(i, current);
                sink(current);
            }
        }

    @Override
    public Comparable<String> dequeue() {
        String result = Heap.get(0);
        Heap.set(0, Heap.get(size-1));
        Heap.remove(size-1);
        sink(0);
        size--;
        return result;
    }


        @Override
        public void enqueue(Comparable item) {
            Heap.add(size, (String) item);
            int current = size;
            while (current != 0 && Heap.get(current).length() > (Heap.get(parent(current))).length()) {
                swap(current, parent(current));
                current = parent(current);
            }
            size++;
        }
        public String head() {
            return Heap.get(0);
        }

        @Override
        public String toString (){
            for (String s : Heap){
                System.out.println(s);
            }
            return null;
        }

    @Override
    public Iterator iterator() {
        Iterator<String> iterator = Heap.iterator();
        return iterator;
    }


    class QueueIterator<T> implements Iterator<T>{
        int rover = 0;
        @Override
        public boolean hasNext() {
            return rover < Heap.size() -1;
        }

        @Override
        public T next() {
            T result = (T) Heap.get(rover);
            rover ++;
            return result;
        }
    }
    }

    //test method - iterative
    /*
            public Comparable<String> dequeue() {
            String result = Heap.get(0);
            Heap.set(0, Heap.get(size-1));
            Heap.remove(size-1);
            size--;
            int current = 0;

                while (leftChild(current) < this.size){
                    if (rightChild(current) < this.size){
                        if (Heap.get(current).compareTo(Heap.get(leftChild(current))) == -1 || Heap.get(current).compareTo(Heap.get(rightChild(current))) == -1){
                            if (Heap.get(leftChild(current)).compareTo(Heap.get(rightChild(current))) == 1) {
                                swap(current, leftChild(current));
                                current = leftChild(current);
                            } else {
                                swap(current, rightChild(current));
                                current = rightChild(current);
                            }
                        }
                    }
                    else if (Heap.get(leftChild(current)).compareTo(Heap.get(current)) == 1){
                        swap(leftChild(current), current);
                        current = leftChild(current);
                    }
            }
              return result;
        }
     */

