//Ryan Carlsmith
//Mr. Paige
//Algorithms H
//1/15/22
public interface PriorityQueue<T extends Comparable<T>> extends Iterable<T> {

        int size();
        boolean isEmpty();

        void enqueue(T item);

        T dequeue();
        T head();

    }

