/*Ryan Carlsmith
Algorithms H
12/4/21
Homework 13
*/


public class Homework_13 {

    public static void main(String[] args) {
        SinglyLinkedList<String> list = new SinglyLinkedList<String>();
        for (String arg : args) {
            list.append(arg);
        }
        list.sort(new comparator<String>(), list);
        list.reverse();
        for (int i =0; i < list.size(); i++){
            System.out.println(list.get(i));
        }
    }
}



