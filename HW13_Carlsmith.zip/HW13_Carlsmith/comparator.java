

import java.util.Comparator;

public class comparator<T extends Comparable> implements java.util.Comparator<T> {

    @Override
    public int compare(T a, T b){
        if (a instanceof String){
            return ((String) b).toLowerCase().compareTo(((String) a).toLowerCase());
        }
        return b.compareTo(a);
    }
}
