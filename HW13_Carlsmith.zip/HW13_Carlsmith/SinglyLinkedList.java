/*Ryan Carlsmith
Algorithms H
12/4/21
Homework 13
 */
import java.util.*;
import java.lang.*;

public class SinglyLinkedList<T extends Comparable>  {

    private Node head;
    private Node tail;
    private int size;
    public SinglyLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }
    public SinglyLinkedList(T item) {
        this();
        this.append(item);
    }

    public SinglyLinkedList(T[] items) {
        this();
        for (T item : items) {
            this.append(item);
        }
    }

    public int size() {
        return this.size;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    public boolean contains(T item) {
        Node rover = this.head;
        while (rover != null) {
            if (equal(rover.data, item)) return true;
            rover = rover.next;
        }
        return false;
    }

    public int occurrences(T item) {
        int count = 0;
        Node rover = this.head;
        while (rover != null) {
            if (equal(rover.data, item)) count++;
            rover = rover.next;
        }
        return count;
    }

    public Node locate(T item) {
        Node rover = this.head;
        while (rover != null) {
            if (equal(rover.data, item)) return rover;
            rover = rover.next;
        }
        return null;
    }

    private void checkIndexBounds(int index) {
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException("Index: " + index);
        }
    }

    public T get(int index) {
        checkIndexBounds(index);
        Node rover = this.head;
        while (index-- > 0) {
            rover = rover.next;
        }
        return rover.data;
    }

    public void set(int index, T value) {
        checkIndexBounds(index);
        Node rover = this.head;
        while (index-- > 0) {
            rover = rover.next;
        }
        rover.data = value;
    }

    public void prepend(T item) {
        Node node = new Node(item);
        node.next = this.head;
        if (this.head == null) {
            this.tail = node;
        }
        this.head = node;
        this.size++;
    }

    public void append(T item) {
        Node node = new Node(item);
        node.next = null;
        if (this.tail != null) {
            this.tail.next = node;
        } else {
            this.head = node;
        }
        this.tail = node;
        this.size++;
    }

    private Node predecessor(Node node) {
        Node rover = this.head;
        while (rover != null) {
            if (rover.next == node) return rover;
            rover = rover.next;
        }
        return null;
    }

    public void insertAfter(Node position, T item) {
        Node node = new Node(item);
        if (position != null) {
            node.next = position.next;
            position.next = node;
        } else {
            node.next = this.head;
            this.head = node;
        }
        if (node.next == null) {
            this.tail = node;
        }
        this.size++;
    }

    public void insertBefore(Node position, T item) {
        insertAfter(predecessor(position), item);
    }

    public T remove(Node node) {
        Node before = predecessor(node);
        T result = node.data;
        if (before != null) {
            before.next = node.next;
        } else {
            this.head = node.next;
        }
        if (node.next == null) {
            this.tail = before;
        }
        this.size--;
        return result;
    }

    public void removeAll(T item) {
        Node rover = this.head;
        Node previous = null;
        while (rover != null) {
            Node next = rover.next;
            if (equal(rover.data, item)) {
                if (previous != null) {
                    previous.next = next;
                } else {
                    this.head = next;
                }
                if (next == null) {
                    this.tail = previous;
                }
                rover.next = null;
                this.size--;
            }
            rover = rover.next;
        }
    }

    public T head() {
        if (this.size > 0) {
            return this.head.data;
        } else {
            throw new EmptyListException();
        }
    }

    public T tail() {
        if (this.size > 0) {
            return this.tail.data;
        } else {
            throw new EmptyListException();
        }
    }

    public T removeHead() {
        if (this.size == 0) {
            throw new EmptyListException();
        }

        T result = this.head.data;
        this.head = this.head.next;
        this.size--;
        if (this.size == 0) {
            this.tail = null;
        }
        return result;
    }

    public T removeTail() {
        if (this.size == 0) {
            throw new EmptyListException();
        }

        T result = this.tail.data;
        this.tail = predecessor(this.tail);
        if (this.tail != null) {
            this.tail.next = null;
        } else {
            this.head = null;
        }
        this.size--;
        return result;
    }

    public void reverse() {
        this.tail = this.head;
        Node rover = this.head;
        Node previous = null;
        while (rover != null) {
            Node next = rover.next;
            rover.next = previous;
            previous = rover;
            rover = next;
        }
        this.head = previous;
    }

    private boolean equal(T x, T y) {
        if (x == null) {
            return y == null;
        } else {
            return x.equals(y);
        }
    }

    public boolean equals(SinglyLinkedList other) {
        if (other == null) return false;
        if (this.size != other.size) return false;

        Node rover1 = this.head;
        Node rover2 = other.head;

        while (rover1 != null && rover2 != null) {
            if (!equal(rover1.data, rover2.data)) return false;
            rover1 = rover1.next;
            rover2 = rover2.next;
        }
        return rover1 == rover2;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof SinglyLinkedList && this.equals((SinglyLinkedList) other);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        Node rover = this.head;
        while (rover != null) {
            if (rover.data != null) {
                hash = 751 * hash + rover.data.hashCode();
            }
            rover = rover.next;
        }
        return hash;
    }

    @Override
    public String toString() {
        String separator = "";
        String result = "[";
        Node rover = this.head;
        while (rover != null) {
            result += separator;
            result += rover.data;
            separator = ", ";
            rover = rover.next;
        }
        result += "]";
        return result;
    }

    public Iterator<T> iterator() {
        return this.new ListIterator();
    }

    private boolean isLess(T a, T b, Comparator<T> comparator) throws IncomparableException{
        if (comparator != null) {
            return comparator.compare(a, b) < 0;
        } else if (a instanceof Comparable) {
            return (((Comparable) a).compareTo(b) < 0);
        } else if (b instanceof Comparable) {
            return (((Comparable) b).compareTo(a) > 0);
        } else {
            throw new IncomparableException();
        }
    }

    public void sort(comparator<T> comparator, SinglyLinkedList<T> linkedList) throws IncomparableException {
        if (this.size <= 1){
            return;
        }
        SinglyLinkedList even = new SinglyLinkedList();
        SinglyLinkedList odd = new SinglyLinkedList();

            boolean isEven = true;

            while (this.head != null){
                if(isEven) {
                    even.appendNode(this.removeHeadNode());
                    isEven = false;
                }
                else{
                    odd.appendNode(this.removeHeadNode());
                    isEven = true;
                }

            }

            even.sort(comparator, even);
            odd.sort(comparator, odd);
            merge(even, odd, comparator, linkedList);
    }

    public SinglyLinkedList<T> merge(SinglyLinkedList<T> a, SinglyLinkedList<T> b, comparator<T> comparator, SinglyLinkedList<T> result) throws IncomparableException {

        while (a.size > 0 && b.size > 0) {
            if (isLess(a.head(), b.head(), comparator)) {
                result.appendNode(b.removeHeadNode());
            } else {
                result.appendNode(a.removeHeadNode());
            }
        }

        if (a.size == 0){ //empty other b list
            while (b.size > 0){
                result.appendNode(b.removeHeadNode());
            }
        }else if (b.size == 0){  //empty a list
            while (a.size > 0){
                result.appendNode(a.removeHeadNode());
            }
        }
        return result;
    }

    private void appendNode(Node node) {
        node.next = null;
        if (this.tail != null){
            this.tail.next = node;
        }
        else {
            this.head = node;
        }
        this.tail = node;
        this.size++;

    }

    private Node removeHeadNode() {
        if(isEmpty()){
            throw new EmptyListException();
        }
        Node result = this.head;
        this.head = this.head.next;
        this.size--;
        if (this.size <= 0) {
            this.tail = null;
        }

        return result;
    }

    public static class IncomparableException extends RuntimeException{
        public IncomparableException(){
            super("Objects cannot be compared");
        }
    }

    public static class EmptyListException extends RuntimeException {
        public EmptyListException() {
            super();
        }
    }

    private class Node {

        private Node next;
        private T data;

        private Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    private class ListIterator implements Iterator<T> {

        private Node rover;

        public ListIterator() {
            this.rover = SinglyLinkedList.this.head;
        }

        @Override
        public boolean hasNext() {
            return this.rover != null;
        }

        @Override
        public T next() {
            T result = this.rover.data;
            this.rover = this.rover.next;
            return result;
        }
    }
}


